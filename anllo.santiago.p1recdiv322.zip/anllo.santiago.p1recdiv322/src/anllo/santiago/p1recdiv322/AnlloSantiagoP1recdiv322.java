
package anllo.santiago.p1recdiv322;

import model.ConstruccionesRuinosas;
import model.Epoca;
import model.Fosiles;
import model.Hallazgo;
import model.HerramientasAntiguas;
import model.InstitutoNacionaldeArqueología;
import exception.ExceptionHallazgoDuplicado;
import java.time.LocalDate;
import java.time.Month;


public class AnlloSantiagoP1recdiv322 {

    public static void main(String[] args) {
        InstitutoNacionaldeArqueología centroHallazgo = new InstitutoNacionaldeArqueología();
        Hallazgo h1 = new ConstruccionesRuinosas(50001, "Pompeya", LocalDate.of(1550, Month.MARCH, 10), 9, "Ciudad", Epoca.COLONIAL);
        Hallazgo h2 = new Fosiles(50002, "Neuquen", LocalDate.of(1999, Month.AUGUST, 20), 5, "T-REx", true);
        Hallazgo h3 = new HerramientasAntiguas(60000, "Santa Cruz", LocalDate.of(1970, Month.APRIL, 15), 6, "Piedra", "Flecha");
        Hallazgo h4 = new HerramientasAntiguas(60002, "Bariloche", LocalDate.of(1975, Month.FEBRUARY, 17), 8, "Hierro", "Molcajete");
        Hallazgo h5 = new ConstruccionesRuinosas(50001, "Pompeya", LocalDate.of(1550, Month.MARCH, 10), 9, "Ciudad", Epoca.COLONIAL);
        
        centroHallazgo.registrarHallazgo(h1);
                
        
        try{
            centroHallazgo.registrarHallazgo(h5);
        }catch(ExceptionHallazgoDuplicado e){
            System.out.println("Error: " + e.getMessage());
        }
        
        centroHallazgo.listarHallazgos();

    }
    
}
