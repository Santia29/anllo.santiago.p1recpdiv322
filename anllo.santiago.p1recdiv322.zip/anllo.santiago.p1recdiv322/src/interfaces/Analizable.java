
package interfaces;

public interface Analizable {
    
    void analizarEnLaboratorio();
    
}
