
package interfaces;

public interface Restaurable {
    
    void restaurar();
}
