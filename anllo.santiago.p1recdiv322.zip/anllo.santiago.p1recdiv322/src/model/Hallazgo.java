
package model;

import java.time.LocalDate;

public abstract class Hallazgo {
    
    public static int CONTADOR_ID = 50000;
    
    private int id;
    private String lugar;
    private LocalDate fecha;
    private int estadoDeConservacion;
    
    public static final int CONSERVACION_MIN = 1;
    public static final int CONSERVACION_MAX = 10;

    public Hallazgo(int id, String lugar, LocalDate fecha, int estadoDeConservacion) {
        this.id = CONTADOR_ID++;
        this.lugar = lugar;
        this.fecha = fecha;
        this.estadoDeConservacion = estadoDeConservacion;
    }

    public String getLugar() {
        return lugar;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getEstadoDeConservacion() {
        return estadoDeConservacion;
    }

    @Override
    public String toString() {
        return "Hallazgo{" + "id=" + id + ", lugar=" + lugar + ", fecha=" + fecha + 
                ", estadoDeConservacion=" + estadoDeConservacion + '}';
    }
    
    @Override
    public boolean equals(Object o){
        if(this == o) return true;
        if(o == null || getClass() != o.getClass()) return false;
        
        Hallazgo other = (Hallazgo) o;
        return lugar.equals(other.lugar) && fecha.equals(other.fecha);
    }  
    
    @Override
    public int hashCode(){
        return java.util.Objects.hash(fecha, lugar);
    }
    
}
