
package model;

public enum Epoca {
    PRECOLOMBINA, COLONIAL, MODERNA
    
}
