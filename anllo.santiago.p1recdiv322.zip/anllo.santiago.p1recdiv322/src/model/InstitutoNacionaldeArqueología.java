
package model;

import java.util.List;
import java.util.ArrayList;
import exception.ExceptionHallazgoDuplicado;
import interfaces.Analizable;
import interfaces.Restaurable;


public class InstitutoNacionaldeArqueología {
    
    private List<Hallazgo> hallazgos;
    
    public InstitutoNacionaldeArqueología(){
        hallazgos = new ArrayList<>();
    }
    
    public void registrarHallazgo(Hallazgo h) throws ExceptionHallazgoDuplicado{
        for(Hallazgo hallazgo : hallazgos){
            if(hallazgo.equals(h)){
                throw new ExceptionHallazgoDuplicado("Ya existe hallazgo con el mismo lugar y fecha");
            }
        }
        hallazgos.add(h);
    }
    public void listarHallazgos(){
        System.out.println("Lista de Hallazgos");
        for(Hallazgo h : hallazgos){
            System.out.println(h.toString());
            }   
    }
    
    public void ejecutarAnalisis(){
        for(Hallazgo h: hallazgos){
            if(h instanceof Analizable){
                ((Analizable) h).analizarEnLaboratorio();
            }else{
                System.out.println("No requiere de Analisis");
            }
        }
    }
    
    public void realizarRestauracion(){
        for(Hallazgo h: hallazgos){
            if(h instanceof Restaurable){
                ((Restaurable) h).restaurar();
            }else{
                System.out.println("No requiere de Restauracion");
            }
        }
    }
    
    public List<Hallazgo> filtrarHallazgoPorEpoca(Epoca epoca) {
        List<Hallazgo> resultado = new ArrayList<>();
        for (Hallazgo h : hallazgos) {
            if (h instanceof ConstruccionesRuinosas) {
                ConstruccionesRuinosas c = (ConstruccionesRuinosas) h;
                if (c.getEpoca() == epoca) {
                    resultado.add(c);
                }
            }
        }
        return resultado;
    }    
    
    
}
    
/*

+ mostrarHallazgoPorEstadoConservacion(): void

*/