
package model;

import interfaces.Analizable;
import java.time.LocalDate;

public class HerramientasAntiguas extends Hallazgo implements Analizable {
    
    private String material;
    private String usoProbable;

    public HerramientasAntiguas(int id, String lugar, LocalDate fecha, int estadoDeConservacion, String material, String usoProbable) {
        super(id, lugar, fecha, estadoDeConservacion);
        this.material = material;
        this.usoProbable = usoProbable;
    }

    @Override
    public void analizarEnLaboratorio() {
        System.out.println("Heramienta Antigua Siendo Analizada");
    }

    @Override
    public String toString() {
        return super.toString() + "HerramientasAntiguas{" + "material=" + material + ", usoProbable=" + usoProbable + '}';
    }
    
    
}
