
package model;

import interfaces.Analizable;
import java.time.LocalDate;

public class Fosiles extends Hallazgo implements Analizable {
    
    private String especieDescubierta;
    private boolean esqueletoCompleto;

    public Fosiles(int id, String lugar, LocalDate fecha, int estadoDeConservacion, String especieDescubierta, boolean esqueletoCompleto) {
        super(id, lugar, fecha, estadoDeConservacion);
        this.especieDescubierta = especieDescubierta;
        this.esqueletoCompleto = esqueletoCompleto;
    }

    @Override
    public void analizarEnLaboratorio() {
        System.out.println("Fosil siendo Analizado");
    }

    @Override
    public String toString() {
        return super.toString() + "Fosiles{" + "especieDescubierta=" + especieDescubierta + '}';
    }
    
    
    
}
