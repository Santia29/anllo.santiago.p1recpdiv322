
package model;

import interfaces.Restaurable;
import java.time.LocalDate;

public class ConstruccionesRuinosas extends Hallazgo implements Restaurable{
    
    private final String tipoEdificacion;
    private Epoca epoca;

    public ConstruccionesRuinosas(int id, String lugar, LocalDate fecha, int estadoDeConservacion, String tipoEdificacion, Epoca epoca) {
        super(id, lugar, fecha, estadoDeConservacion);
        this.tipoEdificacion = tipoEdificacion;
        this.epoca = epoca;
    }

    @Override
    public void restaurar() {
        System.out.println("Construccion siendo restaurada");
    }

    public Epoca getEpoca() {
        return epoca;
    }
    
    @Override
    public String toString() {
        return super.toString() + "ConstruccionesRuinosas{" + "tipoEdificacion=" + tipoEdificacion + ", epoca=" + epoca + '}';
    }
    
    
    
    
    
}
