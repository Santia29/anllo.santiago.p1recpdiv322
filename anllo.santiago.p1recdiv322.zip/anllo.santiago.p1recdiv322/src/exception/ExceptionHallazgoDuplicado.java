
package exception;

public class ExceptionHallazgoDuplicado extends RuntimeException {
    
    public ExceptionHallazgoDuplicado(String mensaje){
        super(mensaje);
    }
    
}
